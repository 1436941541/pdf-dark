import integration from './next-config.cjs';

export const { isPulseSourceMapsEnabled, withPulseSourceMaps } = integration;
