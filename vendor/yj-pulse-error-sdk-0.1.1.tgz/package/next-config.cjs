const { resolve } = require('node:path');

/** No upload credentials or explicit flag means the existing build is untouched. */
function isPulseSourceMapsEnabled({ enabled } = {}) {
  if (enabled !== undefined) return enabled === true;
  if (process.env.YJ_PULSE_SOURCE_MAPS === 'false') return false;
  return process.env.YJ_PULSE_SOURCE_MAPS === 'true' || Boolean(process.env.YJ_PULSE_API_KEY);
}

/**
 * Wrap other build plugins last. Their uploads run first, then Pulse uploads and
 * removes the public maps. Other plugins must retain maps until this hook runs.
 */
function withPulseSourceMaps(config = {}, options = {}) {
  if (!isPulseSourceMapsEnabled(options)) return config;
  const previous = config.compiler?.runAfterProductionCompile;
  const release =
    process.env.YJ_PULSE_RELEASE ||
    process.env.NEXT_PUBLIC_PULSE_RELEASE ||
    config.env?.NEXT_PUBLIC_PULSE_RELEASE ||
    process.env.VERCEL_GIT_COMMIT_SHA ||
    '';
  // Capture one immutable build configuration: the public collector label and
  // uploaded artifacts cannot drift if another plugin changes process.env.
  const upload = {
    baseUrl: process.env.YJ_PULSE_URL,
    websiteId: process.env.YJ_PULSE_WEBSITE_ID,
    release,
    apiKey: process.env.YJ_PULSE_API_KEY,
  };
  return {
    ...config,
    env: { ...config.env, NEXT_PUBLIC_PULSE_RELEASE: release },
    productionBrowserSourceMaps: true,
    compiler: {
      ...config.compiler,
      async runAfterProductionCompile(context = {}) {
        if (previous) await previous.call(this, context);
        const { uploadSourceMaps } = await import('./upload-sourcemaps.mjs');
        await uploadSourceMaps({
          ...upload,
          directory: resolve(
            context.projectDir || process.cwd(),
            context.distDir || config.distDir || '.next',
            'static',
          ),
          urlPrefix: '/_next/static',
        });
      },
    },
  };
}

module.exports = { isPulseSourceMapsEnabled, withPulseSourceMaps };
