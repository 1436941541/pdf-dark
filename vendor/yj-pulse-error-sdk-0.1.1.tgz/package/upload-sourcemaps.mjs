#!/usr/bin/env node
import { readdir, readFile, stat, unlink } from 'node:fs/promises';
import { relative, resolve, sep } from 'node:path';
import { pathToFileURL } from 'node:url';

const MAX_BYTES = 2 * 1024 * 1024;
const MAX_INPUT_BYTES = 16 * 1024 * 1024;
const MAX_OFFSET_LINES = 10000;
const MAX_SECTION_DEPTH = 8;

function standardMap(input, name) {
  let lineOffset = 0;
  let depth = 0;
  while (input && Object.hasOwn(input, 'sections')) {
    // Next's native debug-ID banner wraps the map in one line-shifted section.
    // More complex maps need a full mapping library; never approximate them.
    if (
      ++depth > MAX_SECTION_DEPTH ||
      input.version !== 3 ||
      input.sourceRoot !== undefined ||
      !Array.isArray(input.sections) ||
      input.sections.length !== 1
    )
      throw new Error(`Unsupported indexed source map: ${name}`);
    const section = input.sections[0];
    if (
      !section ||
      section.url !== undefined ||
      !section.map ||
      !Number.isSafeInteger(section.offset?.line) ||
      section.offset.line < 0 ||
      section.offset.column !== 0 ||
      lineOffset + section.offset.line > MAX_OFFSET_LINES
    )
      throw new Error(`Unsupported indexed source map: ${name}`);
    lineOffset += section.offset.line;
    input = section.map;
  }
  if (
    input?.version !== 3 ||
    !Array.isArray(input.sources) ||
    !Array.isArray(input.names) ||
    typeof input.mappings !== 'string'
  )
    throw new Error(`Invalid source map: ${name}`);
  const map = {};
  for (const key of [
    'version',
    'file',
    'sourceRoot',
    'sources',
    'sourcesContent',
    'names',
    'mappings',
    'ignoreList',
  ]) {
    if (input[key] !== undefined) map[key] = input[key];
  }
  // A semicolon is an empty generated line; original source coordinates stay intact.
  if (lineOffset) map.mappings = ';'.repeat(lineOffset) + map.mappings;
  return map;
}

function referencedMap(reference, asset, base, urlPrefix) {
  if (
    !reference ||
    reference.length > 2048 ||
    /[%?#\\]/.test(reference) ||
    [...reference].some(char => char.charCodeAt(0) <= 32 || char.charCodeAt(0) === 127) ||
    /^[a-z][a-z0-9+.-]*:/i.test(reference) ||
    reference.startsWith('//') ||
    reference.split('/').some(part => part === '..' || part === '.')
  )
    throw new Error(`Invalid source map reference: ${asset.name}`);
  let path;
  if (reference.startsWith('/')) {
    const prefix = `${urlPrefix.replace(/\/$/, '')}/`;
    if (!reference.startsWith(prefix))
      throw new Error(`Invalid source map reference: ${asset.name}`);
    path = resolve(base, reference.slice(prefix.length));
  } else path = resolve(asset.full, '..', reference);
  const inside = relative(base, path);
  if (!inside || inside.startsWith(`..${sep}`) || inside === '..')
    throw new Error(`Invalid source map reference: ${asset.name}`);
  return path;
}

async function walkFiles(directory, visit) {
  for (const entry of (await readdir(directory, { withFileTypes: true })).sort((a, b) =>
    a.name.localeCompare(b.name),
  )) {
    const full = resolve(directory, entry.name);
    // Neither artifact collection nor cleanup may follow a symlink.
    if (entry.isSymbolicLink()) continue;
    if (entry.isDirectory()) await walkFiles(full, visit);
    else if (entry.isFile()) await visit(full, entry.name);
  }
}

export async function collectSourceMaps(directory, urlPrefix = '/_next/static') {
  if (!urlPrefix.startsWith('/') || urlPrefix.startsWith('//') || /[?#\\]/.test(urlPrefix)) {
    throw new Error('url-prefix must be an absolute asset path');
  }
  const base = resolve(directory);
  const files = [];
  const inventory = new Map();
  const assets = [];
  await walkFiles(base, async (full, name) => {
    inventory.set(full, name);
    if (/\.m?js$/.test(name)) assets.push({ full, name });
  });
  const prepared = new Map();
  for (const asset of assets) {
    const text = await readFile(asset.full, 'utf8');
    const references = [...text.matchAll(/^\s*\/\/[#@]\s*sourceMappingURL=([^\s]+)\s*$/gm)];
    if (!references.length) continue;
    const full = referencedMap(references.at(-1)[1], asset, base, urlPrefix);
    const name = inventory.get(full);
    // Only files reached by the non-symlink inventory may be read.
    if (!name || !/\.m?js\.map$/.test(name))
      throw new Error(`Missing or unsafe source map: ${asset.name}`);
    let artifact = prepared.get(full);
    if (!artifact) {
      if (files.length >= 200) throw new Error('Too many source maps (maximum 200)');
      if ((await stat(full)).size > MAX_INPUT_BYTES) {
        throw new Error(`Source map input exceeds 16 MiB: ${name}`);
      }
      let map;
      try {
        map = JSON.parse(await readFile(full, 'utf8'));
      } catch {
        throw new Error(`Invalid source map JSON: ${name}`);
      }
      map = standardMap(map, name);
      let sourcesContentOmitted = false;
      if (Buffer.byteLength(JSON.stringify(map)) > MAX_BYTES && map.sourcesContent) {
        // Inline source text is optional. Large dependency maps (for example
        // PDF.js) still resolve exact names/lines without embedding their source.
        // Do not alter the original file: an earlier uploader may need it intact.
        const { sourcesContent: _inlineSources, ...mappingOnly } = map;
        map = mappingOnly;
        sourcesContentOmitted = true;
      }
      if (Buffer.byteLength(JSON.stringify(map)) > MAX_BYTES) {
        throw new Error(`Source map mappings exceed 2 MiB: ${name}`);
      }
      artifact = { map, sourcePath: full, sourcesContentOmitted };
      prepared.set(full, artifact);
    }
    if (files.length >= 200) throw new Error('Too many source maps (maximum 200)');
    const filename = `${urlPrefix.replace(/\/$/, '')}/${relative(base, asset.full).split(sep).join('/')}`;
    files.push({ filename, ...artifact });
  }
  return files;
}

export async function uploadSourceMaps({
  baseUrl,
  websiteId,
  release,
  apiKey,
  directory,
  urlPrefix = '/_next/static',
  fetchImpl = fetch,
}) {
  let base;
  try {
    base = new URL(baseUrl);
  } catch {
    throw new Error('Invalid monitoring URL');
  }
  if (
    (base.protocol !== 'https:' &&
      !(
        base.protocol === 'http:' && ['localhost', '127.0.0.1', '[::1]'].includes(base.hostname)
      )) ||
    base.username ||
    base.password ||
    base.search ||
    base.hash
  )
    throw new Error('Invalid monitoring URL');
  if (
    !/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(websiteId) ||
    typeof release !== 'string' ||
    !/^[A-Za-z0-9._@+:/-]{1,100}$/.test(release) ||
    typeof apiKey !== 'string' ||
    !apiKey
  )
    throw new Error('websiteId, release and API key are required');
  const artifacts = await collectSourceMaps(directory, urlPrefix);
  if (!artifacts.length)
    throw new Error('No client source maps found; enable the build option first');
  const endpoint = `${base.origin}${base.pathname.replace(/\/$/, '')}/api/websites/${websiteId}/errors/artifacts`;
  for (const artifact of artifacts) {
    const response = await fetchImpl(endpoint, {
      method: 'POST',
      // Maps include private source text; never forward them to a redirected URL.
      redirect: 'error',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({ release, filename: artifact.filename, map: artifact.map }),
      signal: AbortSignal.timeout(15000),
    });
    if (!response.ok)
      throw new Error(
        `Source map upload failed (HTTP ${response.status}) for ${artifact.filename}`,
      );
  }
  // Keep maps private: only remove after every artifact is accepted. A failure
  // rejects the production build, so a partially uploaded release is not deployed.
  // CSS maps also contain sourceContent. Sentry must retain all maps so both
  // services can upload, but none may remain in the successful public build.
  await walkFiles(resolve(directory), async (full, name) => {
    if (name.endsWith('.map')) await unlink(full);
  });
  const compacted = artifacts.filter(artifact => artifact.sourcesContentOmitted).length;
  return {
    uploaded: artifacts.length,
    release,
    ...(compacted && { mapsWithoutInlineSources: compacted }),
  };
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  const args = process.argv.slice(2);
  const value = flag => {
    const at = args.indexOf(flag);
    return at < 0 ? undefined : args[at + 1];
  };
  uploadSourceMaps({
    baseUrl: process.env.YJ_PULSE_URL,
    websiteId: process.env.YJ_PULSE_WEBSITE_ID,
    release:
      process.env.YJ_PULSE_RELEASE ||
      process.env.NEXT_PUBLIC_PULSE_RELEASE ||
      process.env.VERCEL_GIT_COMMIT_SHA,
    apiKey: process.env.YJ_PULSE_API_KEY,
    directory: value('--dir') || '.next/static',
    urlPrefix: value('--url-prefix') || '/_next/static',
  })
    .then(result => console.log(JSON.stringify(result)))
    .catch(error => {
      // Only controlled status/path messages are logged, never request headers or API credentials.
      console.error(
        error instanceof Error && !/fetch|URL/i.test(error.message)
          ? error.message
          : 'Source map upload failed',
      );
      process.exitCode = 1;
    });
}
