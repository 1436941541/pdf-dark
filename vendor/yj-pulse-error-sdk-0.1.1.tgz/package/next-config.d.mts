export interface PulseSourceMapOptions {
  enabled?: boolean;
}

export interface PulseCompileContext {
  projectDir?: string;
  distDir: string;
}

export interface PulseCompiledConfig {
  productionBrowserSourceMaps: true;
  env: { NEXT_PUBLIC_PULSE_RELEASE: string };
  compiler: {
    runAfterProductionCompile(context: PulseCompileContext): Promise<void>;
  };
}

export function isPulseSourceMapsEnabled(options?: PulseSourceMapOptions): boolean;
export function withPulseSourceMaps<T extends object>(config: T, options: { enabled: false }): T;
export function withPulseSourceMaps<T extends object>(
  config: T,
  options: { enabled: true },
): T & PulseCompiledConfig;
export function withPulseSourceMaps<T extends object = object>(
  config?: T,
  options?: PulseSourceMapOptions,
): T & Partial<PulseCompiledConfig>;
