# @yj-pulse/error-sdk（本地开发版）

统一网站错误接入。复用 Umami `dev` 提交 `c958b37721e263994d2551888efb56f8fb4524c0` 的 MIT 错误采集设计，并增加有界结构化诊断、任务取消语义和框架/Worker 适配器。尚未发布 npm；当前从本 workspace 构建/安装，或复制带版本记录的构建产物。生产平台和站点需完成兼容部署后才能使用。

## 普通网页：一段脚本

```html
<script defer src="https://yj-pulse.vercel.app/p.js?pulse-errors=0.1.1"
  data-website-id="YOUR_WEBSITE_UUID" data-errors="true"
  data-release="YOUR_GIT_SHA" data-environment="production"></script>
```

既有不带 `data-errors` 的接入保持原样。开启后捕获脚本加载之后的浏览器未处理异常和 Promise 拒绝；错误不会生成 PV 或转化事件。遵守现有 domains、DNT、disabled 和 before-send 设置；`data-auto-pageview="false"` 不影响错误采集，`data-auto-track="false"` 禁止初始化。`data-error-resources="true"` 可选记录 script/link/img 加载失败，不采集元素内容或请求体。

业务已经捕获的错误使用统一接口，无需定制接收端或页面：

```js
try {
  await convert();
} catch (error) {
  void window.umami.captureException(error, {
    contexts: { conversion: { step: 'decode', page: 12, cacheBytes: 2048 } },
    tags: { feature: 'convert' },
  });
  // 保持项目原有的失败处理。
}
```

## SDK 与统一诊断

```ts
import { createErrorClient, attachBrowserErrors } from '@yj-pulse/error-sdk';
const monitor = createErrorClient({
  website: 'YOUR_WEBSITE_UUID',
  endpoint: 'https://yj-pulse.vercel.app/api/p',
  release: 'YOUR_GIT_SHA', // Next客户端可一次配置为 process.env.NEXT_PUBLIC_PULSE_RELEASE
});
attachBrowserErrors(monitor); // 同一 client/target 重复调用不会重复安装。
monitor.setContext('reader', { page: 12 });
monitor.addBreadcrumb({ category: 'conversion', message: 'decode started', data: { page: 12 } });
void monitor.captureException(error, { contexts: { cache: { bytes: 2048 } } });
await monitor.flush(); // 退出服务进程或测试时显式等待；浏览器业务通常无需等待。
monitor.dispose(); // 清理 SDK 安装的监听与待发送队列。
```

`contexts` 只接受有界 JSON，深度不超过5、节点不超过300、字符串不超过1000字符；自动丢弃循环、非普通对象、敏感键和 data/blob URL 内容。breadcrumbs 最多30条；原始 stack 最多16000字符，原因链最多3层。整包不超过48000字节；超限先缩减轨迹和上下文。不得传入 PDF/图片内容、完整请求体、凭据或个人文件名。

`beforeSend(payload)` 可修改或返回空值拒绝发送；修改结果仍重新清洗，不能改变 website/eventId。发送失败、超时、限流或 hook 异常均不向业务抛出。队列/速率/重试均有上限；重试保留相同 eventId。`flush()` 会先等待已经开始的异步准备，再等待发送，默认最多5秒（`flushTimeoutMs` 可配置1–30000毫秒）；超过预算仍安全返回。服务端再次验证、清洗和限流。

## 任务取消

```ts
const operation = monitor.startOperation('convert');
// 用户明确点击取消时：
operation.cancel('user');
// 此后该任务的迟到错误被排除：
void operation.captureException(error);
operation.finish();
```

只有 `status='cancelled' && cancelReason='user'` 被抑制。活跃任务的 `AbortError`、网络错误，以及 timeout/unknown 等取消原因仍上报。不要仅按错误名字判断人为取消。业务步骤/页号与取消动作必须由项目提供，SDK 无法从任意失败结果推断这些语义。

## Worker：公共适配器

```ts
import { wrapWorker } from '@yj-pulse/error-sdk';
const worker = wrapWorker(monitor, () => new Worker(new URL('./worker.ts', import.meta.url)), { operation });
```

不全局替换 Worker 构造函数。工厂返回的原 Worker 保持原样，创建异常在报告后原样抛出。可只给现有 Worker 安装 `attachWorker(monitor, worker, options)`，返回清理函数。

Worker 入口可统一安装：

```ts
import { installWorkerReporter } from '@yj-pulse/error-sdk';
const workerMonitor = installWorkerReporter({ website: 'YOUR_WEBSITE_UUID' }, self);
// 被 Worker 自己 catch 的业务失败：
void workerMonitor.captureException(error, { contexts: { job: { page: 12 } } });
```

入口通过 SDK 的安全消息协议把诊断交回主线程，无需把凭据放进 Worker。主线程只识别这个明确协议，不猜测任意 `postMessage` 的业务含义。标准 uncaught Error 与桥接记录会在短窗口内成对去重，保留完整桥接 stack，并不阻止浏览器原生错误传播。

## React / Next / 服务端

`createReactErrorHandler(monitor)` 可直接接已有 ErrorBoundary 的 onError，无需引入额外 React 依赖。`withErrorMonitoring(monitor, handler)` 适配 API/作业入口，保留 this、参数、同步返回值和异步结果，并原样重抛异常；它不会自动识别 `{success:false}` 等项目业务协议。

服务端只使用独立入口，密钥仅保留在服务端环境：

```ts
import { createServerErrorClient, createNextRequestErrorHandler } from '@yj-pulse/error-sdk/server';
const monitor = createServerErrorClient({
  website: process.env.YJ_PULSE_WEBSITE_ID!,
  endpoint: `${process.env.YJ_PULSE_URL}/api/errors/ingest`,
  apiKey: process.env.YJ_PULSE_API_KEY!,
  release: process.env.YJ_PULSE_RELEASE,
});
export const onRequestError = createNextRequestErrorHandler(monitor);
```

服务端使用 Bearer API key 并经站点权限校验；浏览器公开采集不会携带该 key。只允许 HTTPS 接收地址，loopback 本地验收可使用 HTTP；拒绝地址中的 userinfo、query 和 hash。地址无效、缺少密钥或误在浏览器初始化时，返回 `configuration.enabled=false` 与安全错误码，不发送请求，也不让初始化异常中断原有业务。Next hook 等待有界发送；其他短生命周期服务需在适当的框架 background/waitUntil/退出钩子中调用 `flush()`。浏览器脚本无法覆盖服务端错误。

源码映射构建入口由 `./next-config` 与 `yj-pulse-upload-maps` 提供，按 website/release/filename 上传与还原；仍保留原始 stack。Next插件自动注入公开的 NEXT_PUBLIC_PULSE_RELEASE，上传成功后移除将发布的 client .map，失败则终止构建。短生命周期 `flush()` 会等待正在准备的捕获，默认预算5秒，可配置 flushTimeoutMs（最大30秒）。详见平台 `docs/error-tracking.md`。

## 边界

不保证捕获脚本加载前的错误、浏览器被系统强杀或没有提供 stack 的原生故障。跨域脚本需要正确 CORS 才可能获得完整异常。全局监听不能自动发现被业务吞掉的错误，深度诊断使用上面的统一可选接口。网络、Worker 及应用处理行为保持项目原有语义。


## 0.1.1：自动操作轨迹和构建映射

`attachBrowserErrors(monitor)` 在真正的浏览器 Window 上安装有界轨迹：navigation、fetch、XHR、ui.click。共享 tracker 仅在显式开启错误采集时使用该适配器；`createErrorClient` 本身不修改全局 API。轨迹最多30条，网络观察各最多50个在途请求，detach/dispose会清理订阅。可用 `attachBrowserErrors(monitor, window, { captureBreadcrumbs: false })` 只捕获异常。

不读取控件文字、输入值、文件名/内容、请求头、请求体或响应体。请求地址去掉查询、fragment和账号信息，路径中的文件名和不透明ID脱敏；data/blob地址及采集器自身请求不入轨迹。禁用期间的操作不应在重新启用后补发。有限、非负的 `_chars` 数值统计可保留，含真实 dataURL/secret 的文本继续过滤。

Next.js配置示例（将Pulse放在已有Sentry等插件的最外层）：

```js
import { isPulseSourceMapsEnabled, withPulseSourceMaps } from '@yj-pulse/error-sdk/next-config';
const enabled = isPulseSourceMapsEnabled();
const configured = withOtherPlugin(nextConfig); // 若该插件上传maps，必须保留maps给Pulse
export default withPulseSourceMaps(configured, { enabled });
```

只在构建服务端配置：

```dotenv
YJ_PULSE_SOURCE_MAPS=true
YJ_PULSE_URL=https://YOUR_PULSE_HOST
YJ_PULSE_WEBSITE_ID=YOUR_WEBSITE_UUID
YJ_PULSE_API_KEY=SERVER_ONLY_KEY
YJ_PULSE_RELEASE=UNIQUE_BUILD_RELEASE
```

插件将同一个release注入公开的 `NEXT_PUBLIC_PULSE_RELEASE`；上传key不得使用 `NEXT_PUBLIC_` 前缀。无开关且无上传key时原构建保持；`YJ_PULSE_SOURCE_MAPS=false` 可明确禁用。已有上传key会按兼容逻辑启用；启用后缺配置、超限、HTTP错误或重定向均让构建失败，不静默跳过。

Next TS配置既支持ESM import也支持CJS require。Sentry先上传完整maps（启用Pulse时设置 `sourcemaps.deleteSourcemapsAfterUpload=false`），Pulse上传全部成功后再移除公开static目录内JS/CSS `.map`。上传拒绝重定向；不向错误stack里的任意URL抓取源码。

每个map上限2MiB；仅超限map的上传副本会去除可选 `sourcesContent`，保留精确行列映射。该类帧可能没有源码上下文行，Sentry仍拿完整map。精简后仍超限即失败。当前Next插件按默认 `/_next/static` 发布路径上传；带basePath或有路径assetPrefix的应用须使用CLI `--url-prefix` 与实际公开脚本路径对齐，不能直接假定默认插件覆盖这些配置。

上传的 `filename` 来自真实JS/MJS文件及其 `sourceMappingURL` 引用，不从物理 `.map` 文件名猜测。多个脚本引用同一map时，为每个实际脚本URL分别上传；未被引用的孤立map不会伪造资源URL。只读取构建目录内非symlink文件，拒绝外部URL、路径穿越、编码路径、query/hash及symlink引用；缺失的引用明确使构建失败。

支持标准v3 map，以及Next/Sentry原生debug ID产生的单section纯行偏移包装：在上传副本的 `mappings` 前添加对应空行分隔符，保留内层 `sourceRoot`、名称和精确坐标，再按上述2MiB规则处理内联源码。最多展开8层、累计10000行；父层含 `sourceRoot`、多section、外部section、非零列偏移及越界偏移明确失败，不做近似映射或提高平台上限。Sentry仍读取原始完整map，磁盘文件不因规整而改写。

当前包尚未发布npm。携带tgz的项目应将其纳入版本控制并刷新lockfile integrity；更新共享tracker时也更新缓存版本参数，避免旧p.js被浏览器缓存。
